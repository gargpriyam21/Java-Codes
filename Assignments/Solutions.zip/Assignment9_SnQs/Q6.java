package Assignment9_SnQs;

public class Q6 {

}

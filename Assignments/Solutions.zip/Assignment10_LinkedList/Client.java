package Assignment10_LinkedList;

public class Client {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();
		// list.addFirst(50);
		// list.display();
		//
		// list.addLast(60);
		// list.display();
		//
		// list.addFirst(40);
		// list.display();
		//
		// list.addAt(2, 55);
		// list.display();
		//
		// list.addAt(4, 70);
		// list.display();
		//
		// list.addAt(4, 65);
		// list.display();
		//
		// list.addLast(75);
		// list.display();
		//
		// list.addLast(10);
		// list.display();

		// list.addFirst(12);
		// list.addLast(34);
		// list.addLast(33);
		// list.addLast(1);
		// list.addLast(32);
		// list.addLast(45);
		// list.addLast(12);
		// list.addLast(89);
		// list.addLast(67);
		// list.addLast(17);
		// list.display();

		// Q1
		// list.swap(1, 5);
		// list.display();

		// Q2
		// list.removeduplicates();
		// list.display();

		// Q3
		// list.Merge(list);

		// Q4
		// System.out.println(list.midNote());

		// Q5
		// list.bubblesortR();
		// list.selectionsortR();
		// list.insertionsortR();
		// list.MergeSortR();

		// Q6
		// list.bubblesort();
		// list.display();
		// list.selectionsort();
		// list.display();
		// list.insertionsort();
		// list.display();

		// Q7
		// list.addFirst(10);
		// list.addLast(20);
		// list.addLast(20);
		// list.addLast(10);
		// list.display();
		// System.out.println(list.ispalindrome());

		// Q8
		// list.ReverseDI();
		// list.display();
		// list.reverseDR();
		// list.display();

		// Q9
		// list.evenafterodd();
		// list.display();

		// Q10
		// list.ReverseDI();
		// list.display();

		// Q11
		// list.lastntofirst(2);
		// list.display();

		// Q12
		list.addFirst(9);
		list.addFirst(1);
		list.addFirst(6);
		list.addFirst(2);
		list.addFirst(5);
		list.addFirst(4);
		list.addFirst(3);
		list.display();
		list.kreverse(3);
		list.display();
	}

}

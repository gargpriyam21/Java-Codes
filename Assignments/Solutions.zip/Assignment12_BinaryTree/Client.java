package Assignment12_BinaryTree;

public class Client {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		// 18 true 24 true 38 false false true 10 false false true 32 true 44 false false false
		BinaryTree tree = new BinaryTree();
		tree.display();

		// Q1
		// System.out.println(tree.sum());

		// Q2
		// BinaryTree tree2 = new BinaryTree();
		// System.out.println(tree.structident(tree2));

		// Q3
		// System.out.println(tree.isbalanced());

		// Q4
		// tree.displayal(tree.level());

		// Q5
		// tree.nosiblings();

		// Q6
		// tree.removeleaves();
		// System.out.println("*********************");
		// tree.display();

		// Q7
		// tree.printatlevel();

		// Q8
		// tree.printlevel();

	}

}

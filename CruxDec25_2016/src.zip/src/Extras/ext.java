package Extras;
//

//import Lecture12.DynamicStack;
//
//public class ext {
//	public static void Reverse(DynamicStack stack, DynamicStack helper) throws Exception {
//		if (stack.isEmpty()) {
//			return;
//		}
//		int bottom = popbottom(stack);
//
//		Reverse(stack, helper);
//		stack.push(bottom);
//
//	}
//
//	public static int popbottom(DynamicStack stack) throws Exception {
//		int top = stack.pop();
//		if (stack.isEmpty()) {
//			return top;
//		}
//		int bottom = popbottom(stack);
//		stack.push(top);
//		return bottom;
//	}
//}


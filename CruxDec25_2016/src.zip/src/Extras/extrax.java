package Extras;

public class extrax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int retVal = 0;
		while (n != 0) {
			retVal = n + retVal;
			n--;
		}
		System.out.println(retVal);
	}

}

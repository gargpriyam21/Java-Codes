package Extras;

public class getremove {
	
	
//	public V get(K key) throws Exception {
//		int li = HashFunction(key);
//		if (this.bucketArray[li] == null) {
//			System.out.println("null");
//			return null;
//		} else {
//			for (int i = 0; i < this.bucketArray[li].size(); i++) {
//				if (this.bucketArray[li].getAt(i).key == key) {
//					return this.bucketArray[li].getAt(i).value;
//				}
//			}
//			return null;
//		}
//	}
//	
//	public void remove(K key) throws Exception {
//		int li = HashFunction(key);
//		if (this.bucketArray[li] == null) {
//			System.out.println("null");
//		} else {
//			for (int i = 0; i < this.bucketArray[li].size(); i++) {
//				if (this.bucketArray[li].getAt(i).key == key) {
//					this.bucketArray[li].removeAt(i);
//					this.size--;
//					return;
//				}
//			}
//		}
//	}

}

package Extras;

import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		int year = 1997;
		String str = "12.09." + year;
		System.out.println(str);
	}

}

package Lecture3;

public class FaeTOCel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f = 0, c;
		while (f <= 300) {
			c = (f - 32) * 5 / 9;
			System.out.println(f + "\t" + c);
			f = f + 20;
		}

	}

}

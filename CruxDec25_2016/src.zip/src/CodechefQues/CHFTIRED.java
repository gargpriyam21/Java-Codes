package CodechefQues;

import java.util.Scanner;

public class CHFTIRED {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		int NOTC = s.nextInt();

		for (int i = 0; i < NOTC; i++) {
			int a = s.nextInt();
			int b = s.nextInt();
			System.out.println("YES");
		}
	}
}

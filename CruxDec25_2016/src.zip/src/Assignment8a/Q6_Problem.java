package Assignment8a;

import java.util.ArrayList;

public class Q6_Problem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 3, 5, 7, 0 };
		System.out.println("*******************Q6A*******************");
		System.out.println(countgroups(arr));
		System.out.println("*******************Q6B*******************");
		System.out.println(getgroups(arr));
		System.out.println("*******************Q6C*******************");
		printgroups(arr);
	}

	public static int countgroups(int[] arr) {
		
		return 0;
	}

	public static ArrayList<String> getgroups(int[] arr) {

		return null;
	}

	public static void printgroups(int[] arr) {

	}

}

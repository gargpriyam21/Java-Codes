package Assignment8a;

public class Q7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

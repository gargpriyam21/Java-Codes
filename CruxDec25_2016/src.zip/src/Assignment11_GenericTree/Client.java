package Assignment11_GenericTree;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 80 3 40 2 110 0 120 0 60 0 70 1 140 0
		GenericTree tree = new GenericTree();
		tree.display();

		// Q1
		// System.out.println(tree.sum());

		// Q2 Doubt
		// GenericTree tree1 = new GenericTree();
		// System.out.println(tree.isstructidentical(tree1));

		// Q3 Doubt
		// System.out.println(tree.nextlarger(115));

		// Q4
		// System.out.println(tree.secondlargest());

		// Q5
		// System.out.println("The Number Of Leafs in tree:");
		// System.out.println(tree.countleaf());

		// Q6
		// tree.nodewithdepth();
		// System.out.println("***************");
		// tree.display();

	}

}

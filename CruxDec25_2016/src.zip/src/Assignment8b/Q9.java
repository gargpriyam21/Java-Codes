package Assignment8b;

public class Q9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

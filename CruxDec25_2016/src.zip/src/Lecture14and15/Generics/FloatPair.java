package Lecture14and15.Generics;

// Problem - could not reuse data types
public class FloatPair {
	float one;
	float two;
}

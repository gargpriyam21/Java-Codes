package Lecture14and15;

public class Client {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();
		list.addLast(40);
		list.display();
//		LinkedList list1 = new LinkedList();
//		LinkedList list2 = new LinkedList();
//		LinkedList list3 = new LinkedList();
//
//		list.addFirst(50);
//		list.display();
//
//		list.addLast(60);
//		list.display();
//
//		list.addFirst(40);
//		list.display();
//
//		list.addAt(2, 55);
//		list.display();
//
//		list.addAt(4, 70);
//		list.display();
//
//		list.addAt(4, 65);
//		list.display();
//
//		list.addLast(75);
//		list.display();
//
//		// 3 and 4 swap
//		int b = list.getAt(4);
//		int a = list.removeAt(3);
//		list.addAt(3, b);
//		list.removeAt(4);
//		list.addAt(4, a);
//		list.display();

		// System.out.println(list.getFirst());
		// System.out.println(list.getLast());
		// System.out.println(list.getAt(0));
		// System.out.println(list.getAt(3));

		// System.out.println(list.removefirst());
		// list.display();
		//
		// System.out.println(list.removelast());
		// list.display();
		//
		// System.out.println(list.removeAt(2));
		// list.display();

		// list.ReverseDI();
		// list.display();

		// list.ReversePI();
		// list.display();

		// list.ReverseDIR(0, list.size() - 1);
		// list.display();

		// list.ReversePIR();
		// list.display();

		// list.reverseDR();
		// list.display();

		// System.out.println("The Middle Element is: " + list.midNote());

		// System.out.println("The Kth Node From Last is: " + list.kfromend(2));

		// list1.addFirst(10);
		// list1.addLast(20);
		// list1.addLast(30);
		// list1.addLast(40);
		// list1.addLast(50);
		// list1.display();
		//
		// list2.addFirst(25);
		// list2.addLast(35);
		// list2.addLast(70);
		// list2.display();
		//
		// list3 = list1.Merge(list2);
		// list3.display();
		//
		// list1.addFirst(40);
		// list1.addLast(20);
		// list1.addLast(10);
		// list1.addLast(30);
		// list1.addLast(50);
		// list1.display();
		//
		// list3 = list1.MergeSort(list1, 0, list1.size() - 1);
		// list3.display();

	}

}

package Lecture2;

public class SimpleInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p = 1000;
		int r = 10;
		int t = 1;
	}

}
